# TODO
'''
Might have to do some refactoring because the tests for Renderer are included in the test_rasterize* unit tests
'''
